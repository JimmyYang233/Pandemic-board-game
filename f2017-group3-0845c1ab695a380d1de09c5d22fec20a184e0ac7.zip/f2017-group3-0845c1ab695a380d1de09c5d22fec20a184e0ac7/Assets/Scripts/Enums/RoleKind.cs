﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public enum RoleKind
{
    ContingencyPlanner, Dispatcher, Medic, OperationsExpert, QuarantineSpecialist, Researcher, Scientist, Archivist, 
    ContainmentSpecialist, Epidemiologist, FieldOperative, Generalist, Troubleshooter, BioTerrorist
}
