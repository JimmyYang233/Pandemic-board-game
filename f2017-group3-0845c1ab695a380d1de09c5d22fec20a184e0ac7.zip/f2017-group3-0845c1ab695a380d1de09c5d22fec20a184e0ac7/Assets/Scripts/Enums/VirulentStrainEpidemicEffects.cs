using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum VirulentStrainEpidemicEffects
{
    ChronicEffect,ComplexMolecularStructure,GovernmentInterference,HiddenPocket
}